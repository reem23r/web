<?php  

include "config.php"; 

?>
<!DOCTYPE html>
<html>
    <head>
        <link href="style.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-8GbY7cL6q6H26J88lZ2D9RdC5tUv2+VZl7m5R0D9OzNtjz4Q+7rKzP/6Jg6gTl1cUx02AYnYzB8T7/9Ff8CfBQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    </head>
    <body>
    <div class="header">
            <ul>
                <li><a class="link"  href="quiz.php">Add Quiz</a></li>
                 <li><a class="link" >Log in</a></li>
              </ul>
              <a href="index.php" class="logo2">P</a>
        </div>
       
    <div class="formsection">
    <h2> create account</h2>

       <form action="createnew.php" id="form1" method="POST">

        <div>
            <label for="userrname">Username:</label>
            <input type="text" id="username" name="username">
        </div>
        <div>
            <label for="password">password:</label>
            <input type="text" id="password" name="password">
        </div>
        <div>
            <label for="name">Name:</label>
            <input type="text" id="name" name="name">
        </div>
        <div>
            <label for="age">Age:</label>
            <input type="text" id="age" name="age">
        </div>
        <div>
            <label for="note">Note:</label>
            <input type="text" id="note" name="note">
        </div>
        <div class="divbtn">
            <input type="submit" value="Submit" class="btnadd" name="student">
        </div>
           
          </form>
    </div>
    <div>
      <?php

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM student WHERE username='$username' AND password='$password'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
 
  header("Location: index.php");
} 
      ?>
      


    <div class="footer">
    <div>
            &copy; copyright  
                    </div>
           <div>
           <ul class="social-icons">
                 
                 <li><a><i class="fa-brands fa-facebook"></i></a></li>
                  <li><a><i class="fa-brands fa-twitter"></i></a></li>
                 <li><a><i class="fa-brands fa-instagram"></i></a></li>
                
              </ul>
           </div>
         </div>
    </body>
</html>