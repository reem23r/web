

<!DOCTYPE html>
<html>
    <head>
        <link href="style.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-8GbY7cL6q6H26J88lZ2D9RdC5tUv2+VZl7m5R0D9OzNtjz4Q+7rKzP/6Jg6gTl1cUx02AYnYzB8T7/9Ff8CfBQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    </head>
    <body>
    <div class="header">
            <ul>
                <li><a class="link"  href="quiz.php">Add Quiz</a></li>
                 <li><a class="link" >Log in</a></li>
              </ul>
              <a href="index.php" class="logo2">P</a>
        </div>
       
    <div class="formsection">
        <h4>New Quiz</h4>
       <form action="createnew.php" id="form1" method="POST">

        <div>
            <label for="quistion">Quistion:</label>
            <input type="text" id="question" name="question">
        </div>
        <div>
            <label for="choiceone">choice one:</label>
            <input type="text" id="choiseone" name="choiseone">
        </div>
        <div>
            <label for="choicetwo">choice Two:</label>
            <input type="text" id="choisetwo" name="choisetwo">
        </div>
        <div>
            <label for="choicethree">choice Three:</label>
            <input type="text" id="choisethree" name="choisethree">
        </div>
        <div>
            <label for="answer">Answer:</label>
            <input type="number" id="answer" name="answer">
        </div>
        <div>
            <label for="answer">Course:</label>
            <select id="courseid" name="courseid">
            <?php 
                include "config.php";
                $sql = "SELECT id, name   FROM course"; 
                $result = $conn->query($sql); 

                while($row = $result->fetch_assoc()){
                echo '<option value='.$row['id'].'>'.$row['name'].'</option>' ;
                }
            ?>
            </select>
            
        </div>
        
        <div class="divbtn">
            <input type="submit" value="Submit" class="btnadd" name="quiz">
        </div>
           
          </form>
    </div>
        
        
      



    <div class="footer">
            <div>
            &copy; copyright  
                    </div>
           <div>
           <ul class="social-icons">
                 
                 <li><a><i class="fa-brands fa-facebook"></i></a></li>
                  <li><a><i class="fa-brands fa-twitter"></i></a></li>
                 <li><a><i class="fa-brands fa-instagram"></i></a></li>
                
              </ul>
           </div>
         </div>
         
    </body>
</html>