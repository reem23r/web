<?php  

include "config.php"; 

?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style.css">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"  crossorigin="anonymous" referrerpolicy="no-referrer" /> -->
    </head>
   
    <body>
    <nav>
        <div class="header">
            <ul>
                <li><a class="link"  href="quiz.php">Add Quiz</a></li>
                 <li><a class="link" href="login.php">Log in</a></li>
              </ul>
              <a href="index.php" class="logo2">P</a>
        </div>
</nav>
        <div class="intro">
        <h1>programming For all </h1>
        <p>Learn programming skills and basics online</p>

            <a class="btn" href="reem.php"> Learn More</a>

        </div>

        
           
               
            <div class="achievements">
              <div class="work">
                <i class="fas fa-book"></i>

                <p class="work-heading">Courses</p>
                 
                <p class="work-text">Sourcec of computer seience courses in Arabic .</p>
              </div>
              <div class="work">
                <i class="fas fa-book"></i>
                <p class="work-heading">Programming</p>
                <p class="work-text">We provide resources for education and self-development for learning Programming.</p>
              </div>
              <div class="work">
                 <i class="fas fa-book"></i>
                 <p class="work-heading">test</p>
                <p class="work-text">You will find a test for courses for training </p>
              </div>
           </div>







           
        </div>
        <div class="slider">
               <div class="slide">
                 <img src="1.JPG" alt="nofound">
                    <h3 class="TEXTT">Quiz Test</h3>
                    <p>Test yourself to see your leval </p>
                    <a href="showquiz.php"> Start</a>
               </div> 
        </div>
        <div class="slider">
            <div class="slide">
              <img src="2.JPG" alt="nofound">
                 <h3 class="TEXTT">Poubular Course</h3>
                 <p>Start at the begining by learning  basics </p>
                 <a href="course.php"> Start</a> <br>
            </div> 
        </div>
       
         <div class="footer">
            <div>
            &copy; copyright  
            </div>
           <div>
           <ul class="social-icons">
                 
                 <li><a><i class="fa-brands fa-facebook"></i></a></li>
                  <li><a><i class="fa-brands fa-twitter"></i></a></li>
                 <li><a><i class="fa-brands fa-instagram"></i></a></li>
                
              </ul>
           </div>
         </div>
      
         
    </body>
</html>