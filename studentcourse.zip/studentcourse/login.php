
<!DOCTYPE html>
<html>
  <head>
    <title>Login Page</title>
    <style>
      body {
        background-color: #000000;
        color: #ffffff;
        font-family: Arial, sans-serif;
      }
      .container {
        width: 400px;
        margin: 0 auto;
        margin-top: 100px;
        padding: 20px;
        background-color: rgba(0, 0, 0, 0.5);
        border-radius: 5px;
        text-align: center;
      }
      h1 {
        font-size: 36px;
        font-weight: bold;
        margin-top: 0;
      }
      label {
        display: block;
        font-size: 18px;
        font-weight: bold;
        margin-bottom: 10px;
        text-align: left;
      }
      input[type="text"], input[type="password"] {
        padding: 10px;
        border: none;
        border-radius: 5px;
        margin-bottom: 20px;
        width: 100%;
        font-size: 16px;
      }
      input[type="submit"] {
        background-color: #FFFFFF;
        color: #000000;
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 18px;
        font-weight: bold;
      }
      input[type="submit"]:hover {
        background-color: #CCCCCC;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <h1>Login</h1>
      <form method="post" action="student.php">
        <label for="username">Username</label>
        <input type="text" id="username" name="username"><br>
        <label for="password">Password</label>
        <input type="password" id="password" name="password"><br>
        <input type="submit" value="Sign in"><br>

        

            </form>


        </form>


  </body>
</html>