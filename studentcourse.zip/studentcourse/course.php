<!DOCTYPE html>
<html>
<head>
	<title>courses </title>
	<style type="text/css">
		.course-group {
			display: flex;
			flex-wrap: wrap;
			justify-content: center;
			align-items: center;
			margin-bottom: 50px;
		}

		.course-group h2 {
			text-align: center;
			margin-bottom: 20px;
		}

		.course {
			background-color: #f5f5f5;
			border-radius: 5px;
			box-shadow: 0px 0px 5px grey;
			margin: 20px;
			padding: 20px;
			width: 300px;
		}

		.course img {
			display: block;
			margin: auto;
			margin-bottom: 20px;
			max-width: 100%;
			height: auto;
		}

		.course h3 {
			text-align: center;
			margin-bottom: 10px;
		}

		.course p {
			text-align: justify;
			line-height: 1.5;
			margin-bottom: 10px;
		}

		.course a {
			display: block;
			text-align: center;
			background-color: #4CAF50;
			color: white;
			padding: 10px;
			border-radius: 5px;
			text-decoration: none;
			margin-top: 10px;
			font-weight: bold;
			transition: all 0.3s ease;
		}

		.course a:hover {
			background-color: #3e8e41;
		}
	</style>
</head>
 <body>

	<h1>courses</h1>

	<div class="course-group">
		<div class="course">
        <img src="OIP.jfif" alt=" SQL">
			<h3>COURSE 1</h3>
			<p >learn sql</p>
			<a href="https://youtu.be/N-WPYk417yE"> SQL
</a>
		</div>
		<div class="course">
			<img src="jana.jfif" alt=" learn jave">
			<h3>COURSE 2</h3>
			<p > learn jave </p>
			<a href="https://youtu.be/0Nb4wHNj5bE"> Java</a>

		</div>
		<div class="course">
        <img src="OIP (1).jpg" alt=" python"> 
			<h3>COURSE 3</h3>
			<p >learn python</p>
			<a href="https://youtu.be/h3VCQjyaLws"> python
</a>
		</div>
	</div>

	<div class="course-group">
		<div class="course">
			<img src="css.png" alt="دورة 4">
			<h3 4>COURSE 4</h3>
			<p> learn css</p>
			<a href="https://youtu.be/Z-5QVutAEW4">html
</a>
		</div>

		
		<div class="course">
			<img src="php.jfif" alt="دورة 6">
			<h3 4>COURSE 5</h3>
			<p>learn php </p>
			<a href="https://youtu.be/-u9_T_CLZHY"> php</a>
		</div>
		<div class="course">
			<img src="html.jfif " alt="دورة 5">
			<h3 4>COURSE 6</h3>
			<p> learn html</p>
            <a href="https://youtu.be/q3yFo-t1ykw">html
</a></div>
       
	</div>

</body>
</html>