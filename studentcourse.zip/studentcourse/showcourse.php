<!DOCTYPE html>
<html>
    <head>
        <link href="style.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

     </head>
    <body>
    <div class="header">
            <ul>
                <li><a class="link"  href="quiz.php">Add Quiz</a></li>
                <li><a class="link"  href="article.php">Add an article</a></li>
                 <li><a class="link" >Log in</a></li>
                <li><a class="link" >Contact us</a></li>
              </ul>
              <a href="index.php" class="logo2">P</a>
        </div>
     
        <div  class="achievements">
        <?php 
                include "config.php";
                $sql = "SELECT id, name ,price,note   FROM course"; 
                $result = $conn->query($sql); 

                while($row = $result->fetch_assoc()){
                    echo '   <div class="work">';
                    echo ' <i class="fa-solid fa-book"></i>';
                    echo '  <span class="work-heading">'.$row['name'].'</span>';
                    echo '  <p class="work-text">'.$row['note'].'</p> </div>';
                
                        }
            ?>
          
        </div>
        
        
      



        <div class="footer">
        <div>
            &copy; copyright  
                    </div>
           <div>
           <ul class="social-icons">
                 
                 <li><a><i class="fa-brands fa-facebook"></i></a></li>
                  <li><a><i class="fa-brands fa-twitter"></i></a></li>
                 <li><a><i class="fa-brands fa-instagram"></i></a></li>
                
              </ul>
           </div>
         </div>
         
    </body>
</html>