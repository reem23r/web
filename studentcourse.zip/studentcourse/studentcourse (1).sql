-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 28 مايو 2023 الساعة 21:42
-- إصدار الخادم: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentcourse`
--

-- --------------------------------------------------------

--
-- بنية الجدول `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `text` text NOT NULL,
  `note` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `article`
--

INSERT INTO `article` (`id`, `title`, `text`, `note`) VALUES
(1, 'how to learn?', 'ava is a high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible', 'ali');

-- --------------------------------------------------------

--
-- بنية الجدول `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `course`
--

INSERT INTO `course` (`id`, `name`, `price`, `note`) VALUES
(1, 'learning java', 200, 'this is profissional course'),
(2, 'Freelancer ', 200, 'Freelancer  Freelancer  Freelancer  '),
(3, 'Designer', 200, 'Designer Designer Designer Designer'),
(4, 'twitter', 200, 'twittertwittertwittertwitter'),
(5, 'learning java', 200, 'learning javalearning java'),
(6, 'learning java', 200, 'learning java learning java'),
(7, 'learning  css', 0, 'this css');

-- --------------------------------------------------------

--
-- بنية الجدول `quiz`
--

CREATE TABLE `quiz` (
  `id` int(100) NOT NULL,
  `question` varchar(100) COLLATE utf8_estonian_ci NOT NULL,
  `answer` int(50) NOT NULL,
  `choiseone` varchar(50) COLLATE utf8_estonian_ci NOT NULL,
  `choisetwo` varchar(50) COLLATE utf8_estonian_ci NOT NULL,
  `choisethree` varchar(50) COLLATE utf8_estonian_ci DEFAULT NULL,
  `courseid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_estonian_ci;

--
-- إرجاع أو استيراد بيانات الجدول `quiz`
--

INSERT INTO `quiz` (`id`, `question`, `answer`, `choiseone`, `choisetwo`, `choisethree`, `courseid`) VALUES
(2, 'Is html language?', 2, 'yes', 'no', 'space', 1),
(3, 'Is css language?', 2, 'yes', 'no', 'space', 3),
(4, 'Is jslanguage?', 1, 'yes', 'no', 'space', 1);

-- --------------------------------------------------------

--
-- بنية الجدول `student`
--

CREATE TABLE `student` (
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `note` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `student`
--

INSERT INTO `student` (`username`, `password`, `id`, `name`, `age`, `note`) VALUES
('rana', NULL, 1, 'rana alotiby', 12, 22),
('lama', NULL, 2, 'lama', 12, 0),
('nora', '123', 3, 'nora', 22, 0);

-- --------------------------------------------------------

--
-- بنية الجدول `studentquizcourse`
--

CREATE TABLE `studentquizcourse` (
  `id` int(11) NOT NULL,
  `studentid` int(11) NOT NULL,
  `courseid` int(11) NOT NULL,
  `quizid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`id`),
  ADD KEY `courseid` (`courseid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `quiz`
--
ALTER TABLE `quiz`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- قيود الجداول المحفوظة
--

--
-- القيود للجدول `quiz`
--
ALTER TABLE `quiz`
  ADD CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`courseid`) REFERENCES `course` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
