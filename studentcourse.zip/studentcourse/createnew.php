<?php 
 include "config.php";
 

  
 if($_SERVER['REQUEST_METHOD']=='POST' and  isset($_POST['student'])){         

            $username=$_POST['username'];
            $password=$_POST['password'];
            $name=$_POST['name'];
            $age=$_POST['age'];
            $note=$_POST['note'];
            $sql="INSERT INTO `student` (`username`,`password`,`name`, `age`, `note`)
           VALUES ('$username','$password','$name',$age, '$note')";
           if($conn->query($sql) === TRUE){ 
            header("Location:student.php");          
                      }
           else {  echo "Error: " . $sql . "<br>" . $conn->error;
                      
           }     
         }

         if($_SERVER['REQUEST_METHOD']=='POST' and  isset($_POST['course'])){
          $name=$_POST['name'];
          $price=$_POST['price'];
          $note=$_POST['note'];
           
          $sql="INSERT INTO `course` (`name`,`price`,`note`)
         VALUES ('$name','$price', '$note')";
         if($conn->query($sql) === TRUE){ 
          header("Location:index.php");          
                    }
         else {  echo "Error: " . $sql . "<br>" . $conn->error;}


         } 
         if($_SERVER['REQUEST_METHOD']=='POST' and  isset($_POST['article'])){
          $name=$_POST['title'];
          $article=$_POST['text'];
          $note=$_POST['note'];
           
          $sql="INSERT INTO `article` (`title`,`text`,`note`)
         VALUES ('$name','$article', '$note')";
         if($conn->query($sql) === TRUE){ 
          header("Location:index.php");          
                    }
         else {  echo "Error: " . $sql . "<br>" . $conn->error;}


         }
         if($_SERVER['REQUEST_METHOD']=='POST' and  isset($_POST['quiz'])){
          $question=$_POST['question'];
          $answer=$_POST['answer'];
          $choiseone=$_POST['choiseone'];
          $choisetwo=$_POST['choisetwo'];
          $choisethree=$_POST['choisethree'];
          $courseid=$_POST['courseid'];
           
          $sql="INSERT INTO `quiz` (`question`,`answer`,`choiseone`,`choisetwo`,`choisethree`,`courseid`)
         VALUES ('$question',$answer, '$choiseone', '$choisetwo', '$choisethree', $courseid)";
         if($conn->query($sql) === TRUE){ 
          header("Location:index.php");          
                    }
         else {  echo "Error: " . $sql . "<br>" . $conn->error;}


         }
         echo "exit" ;  
                     
             $conn->close(); 
   
        
   
  ?>